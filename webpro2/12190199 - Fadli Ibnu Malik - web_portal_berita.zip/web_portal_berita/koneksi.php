<?php
$koneksi=mysqli_connect("localhost","root","", "db_web_portal_berita")or die(mysqli_error());
?>